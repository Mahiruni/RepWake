/**
 * The landing page demo runs the real rep-counting engine, not a mock. That is
 * the whole point of it: if the demo can be cheated, so can the app.
 *
 * The engine is pure TypeScript with no React Native imports, so it runs
 * unchanged in a browser. This copies it across. Run it after any change to
 * the detection logic, or the site will be demoing stale rules.
 */
import { copyFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const FROM = join(process.cwd(), '..', 'repwake', 'src', 'detection');
const TO = join(process.cwd(), 'lib');
const FILES = ['types.ts', 'repMachine.ts', 'calibration.ts'];

if (!existsSync(FROM)) {
  console.error(`No app source at ${FROM}. Keeping the committed copy in lib/.`);
  process.exit(0);
}
for (const f of FILES) {
  copyFileSync(join(FROM, f), join(TO, f));
  console.log(`synced ${f}`);
}
