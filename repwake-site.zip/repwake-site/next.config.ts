import type { NextConfig } from 'next';

const config: NextConfig = {
  // The site is fully static — no server rendering, no API routes. Vercel
  // serves it from the edge and it costs nothing to run.
  output: 'export',
  images: { unoptimized: true },
};

export default config;
