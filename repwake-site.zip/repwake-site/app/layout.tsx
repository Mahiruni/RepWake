import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RepWake — the alarm that needs push-ups',
  description:
    'An Android alarm that will not turn off until you have done your push-ups, counted by your phone’s own sensors. Free, offline, open source.',
  openGraph: {
    title: 'RepWake — the alarm that needs push-ups',
    description:
      'It counts reps with the proximity sensor while the phone lies on the floor beneath your chest. Try to cheat it in your browser.',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#0e1014',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
