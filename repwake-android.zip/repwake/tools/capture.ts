/**
 * Trace capture. Drop this behind a hidden button in a debug build, do a real
 * set of push-ups, and it writes a JSON file in exactly the shape the fixtures
 * use — so a real recording can be replayed through the state machine in a
 * test without touching a phone.
 *
 * The synthetic fixtures in __tests__/fixtures/traces.ts pin the LOGIC. Only
 * real captures can validate the THRESHOLDS. Record at least: a clean set, a
 * set on carpet, a set by a heavy user on a hard floor, and every cheat you
 * can think of, on at least three different handsets.
 */
import { Native, onAccel, onProximity } from '../src/native/RepWakeAlarm';
import { RepEvent } from '../src/detection/types';

export function startCapture(mode: 'proximity' | 'accel' = 'proximity') {
  const events: RepEvent[] = [];
  Native.startSensors(mode);

  const subP = onProximity(s =>
    events.push({ type: 'PROXIMITY', near: s.raw < s.maxRange / 2, raw: s.raw, t: s.t }),
  );
  const subA = onAccel(s =>
    events.push({ type: 'ACCEL', v: { x: s.x, y: s.y, z: s.z }, t: s.t }),
  );

  return {
    stop(): string {
      subP.remove();
      subA.remove();
      Native.stopSensors();
      events.sort((a, b) => a.t - b.t);
      return JSON.stringify({ mode, capturedAt: new Date().toISOString(), events });
    },
    get count() {
      return events.length;
    },
  };
}
