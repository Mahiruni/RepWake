import { RepEvent, Vec3 } from '../../src/detection/types';

/**
 * Trace fixtures for the rep machine.
 *
 * These are SYNTHETIC traces built from the shape of real sensor output, not
 * captures from a device. They are good enough to pin the state machine's
 * logic, and they are not good enough to prove the thresholds are right on
 * real hardware.
 *
 * `npm run capture` (see tools/capture.ts) dumps a real session to JSON in the
 * same shape. Replace these with captures from at least three handsets before
 * shipping, and keep the synthetic ones as regression cases.
 */

const FLAT: Vec3 = { x: 0, y: 0, z: 9.81 }; // face-up on the floor

/** Small symmetric floor vibration — what a real push-up looks like to a phone. */
function jitter(seed: number, scale = 0.06): Vec3 {
  const a = Math.sin(seed * 12.9898) * 43758.5453;
  const b = Math.sin(seed * 78.233) * 12345.6789;
  const c = Math.sin(seed * 39.425) * 24680.1357;
  return {
    x: FLAT.x + (a - Math.floor(a) - 0.5) * scale,
    y: FLAT.y + (b - Math.floor(b) - 0.5) * scale,
    z: FLAT.z + (c - Math.floor(c) - 0.5) * scale,
  };
}

/** Accel stream at 50 Hz between t0 and t1. */
export function accelStream(
  t0: number,
  t1: number,
  mk: (t: number, i: number) => Vec3 = (_t, i) => jitter(i),
): RepEvent[] {
  const out: RepEvent[] = [];
  let i = 0;
  for (let t = t0; t <= t1; t += 20) out.push({ type: 'ACCEL', v: mk(t, i++), t });
  return out;
}

const byTime = (a: RepEvent, b: RepEvent) => a.t - b.t;

export interface RepShape {
  /** When the chest reaches the sensor. */
  downAt: number;
  /** How long it is held down. */
  holdMs: number;
}

/**
 * A clean set of push-ups: phone flat on the floor, chest covers the sensor
 * for ~400ms per rep, ~1.6s cadence.
 */
export function cleanSet(count: number, cadence = 1600, hold = 400): RepEvent[] {
  const events: RepEvent[] = [];
  let t = 1000;
  for (let i = 0; i < count; i++) {
    events.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    events.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + hold });
    t += cadence;
  }
  return [...accelStream(0, t + 200), ...events].sort(byTime);
}

/** Hand waved rapidly over the sensor — should be rejected on cadence. */
export function handWaveSpam(count: number, cadence = 300): RepEvent[] {
  const events: RepEvent[] = [];
  let t = 1000;
  for (let i = 0; i < count; i++) {
    events.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    events.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + 120 });
    t += cadence;
  }
  return [...accelStream(0, t + 200), ...events].sort(byTime);
}

/** Slow deliberate flicks past the sensor — correct cadence, no hold. */
export function flickSet(count: number, cadence = 1600): RepEvent[] {
  const events: RepEvent[] = [];
  let t = 1000;
  for (let i = 0; i < count; i++) {
    events.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    events.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + 120 }); // < 250ms
    t += cadence;
  }
  return [...accelStream(0, t + 200), ...events].sort(byTime);
}

/**
 * The interesting cheat: phone picked up and waved against the chest at a
 * believable cadence with a believable hold. Only the accelerometer can tell.
 */
export function pickedUpAndWaved(count: number, cadence = 1600): RepEvent[] {
  const events: RepEvent[] = [];
  let t = 1000;
  const end = 1000 + count * cadence + 400;

  for (let i = 0; i < count; i++) {
    events.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    events.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + 400 });
    t += cadence;
  }

  // Phone tilted ~45deg and swung: large orientation change plus real jerk.
  const accel = accelStream(0, end, tt => {
    const ph = (tt / cadence) * 2 * Math.PI;
    const tilt = Math.sin(ph) * 0.7; // radians, ~40deg swing
    const swing = Math.sin(ph * 2) * 3.5;
    return {
      x: Math.sin(tilt) * 9.81 + swing,
      y: Math.sin(tilt * 0.6) * 4.0,
      z: Math.cos(tilt) * 9.81 + swing * 0.5,
    };
  });

  return [...accel, ...events].sort(byTime);
}

/** User goes down and stays down (fell asleep / gave up). */
export function stalledRep(): RepEvent[] {
  const events: RepEvent[] = [
    { type: 'PROXIMITY', near: true, raw: 0, t: 1000 },
    { type: 'PROXIMITY', near: false, raw: 5, t: 12000 },
  ];
  const ticks: RepEvent[] = [];
  for (let t = 1000; t <= 12000; t += 250) ticks.push({ type: 'TICK', t });
  return [...accelStream(0, 12200), ...ticks, ...events].sort(byTime);
}

/** Finger resting on the screen while reps are performed. */
export function touchingSet(count: number): RepEvent[] {
  const touch: RepEvent = { type: 'TOUCH', down: true, t: 500 };
  return [touch, ...cleanSet(count)].sort(byTime);
}

/** Armband mode: vertical oscillation at ~0.6 Hz. */
export function armbandSet(count: number, cadence = 1700): RepEvent[] {
  const end = 500 + count * cadence + 400;
  return accelStream(500, end, tt => {
    const ph = ((tt - 500) / cadence) * 2 * Math.PI;
    const osc = -Math.sin(ph) * 4.0; // dips first, then rises
    return { x: 0.1, y: 0.1, z: 9.81 + osc };
  });
}

/** Genuine push-ups by someone heavy, on a hard floor. Must still count. */
export function heavyLandingSet(count: number, thump = 8, cadence = 1600): RepEvent[] {
  const ev: RepEvent[] = [];
  let t = 1000;
  for (let i = 0; i < count; i++) {
    ev.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    ev.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + 400 });
    t += cadence;
  }
  const acc = accelStream(0, t + 200, tt => {
    const p = ((tt - 1000) % cadence) / cadence;
    const imp = p >= 0 && p < 0.15 ? Math.sin((p / 0.15) * Math.PI) * thump : 0;
    const j = jitter(tt, 0.05);
    return { x: j.x + imp * 0.2, y: j.y + imp * 0.2, z: j.z + imp };
  });
  return [...acc, ...ev].sort(byTime);
}

/**
 * The subtle cheat: phone lifted and translated up and down against the chest
 * without rotating it. Tilt stays near zero, so only the rest-floor test
 * catches it — a hand never goes as still as a floor.
 */
export function levelTranslationCheat(count: number, cadence = 1600): RepEvent[] {
  const ev: RepEvent[] = [];
  let t = 1000;
  for (let i = 0; i < count; i++) {
    ev.push({ type: 'PROXIMITY', near: true, raw: 0, t });
    ev.push({ type: 'PROXIMITY', near: false, raw: 5, t: t + 400 });
    t += cadence;
  }
  const tremor = () => (Math.random() - 0.5) * 0.24; // hand tremor
  const acc = accelStream(0, t + 200, tt => {
    const sw = Math.sin((tt / cadence) * 4 * Math.PI) * 2.0;
    return { x: sw + tremor(), y: tremor(), z: 9.81 + sw * 0.5 + tremor() };
  });
  return [...acc, ...ev].sort(byTime);
}
