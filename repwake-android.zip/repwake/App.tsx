import React, { useState } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, Pressable, Text, View } from 'react-native';
import AlarmListScreen from './src/screens/AlarmListScreen';
import AlarmEditScreen from './src/screens/AlarmEditScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import CalibrationScreen from './src/screens/CalibrationScreen';
import { color, space, type } from './src/theme';

type Tab = 'alarms' | 'history' | 'settings';
type Modal = { kind: 'edit'; id?: string } | { kind: 'calibrate' } | null;

const TABS: Tab[] = ['alarms', 'history', 'settings'];

export default function App() {
  const [tab, setTab] = useState<Tab>('alarms');
  const [modal, setModal] = useState<Modal>(null);

  if (modal?.kind === 'edit') {
    return (
      <SafeAreaView style={s.root}>
        <StatusBar barStyle="light-content" backgroundColor={color.base} />
        <AlarmEditScreen id={modal.id} onDone={() => setModal(null)} />
      </SafeAreaView>
    );
  }
  if (modal?.kind === 'calibrate') {
    return (
      <SafeAreaView style={s.root}>
        <CalibrationScreen onDone={() => setModal(null)} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor={color.base} />
      <View style={s.body}>
        {tab === 'alarms' && (
          <AlarmListScreen onEdit={id => setModal({ kind: 'edit', id })} />
        )}
        {tab === 'history' && <HistoryScreen />}
        {tab === 'settings' && (
          <SettingsScreen onCalibrate={() => setModal({ kind: 'calibrate' })} />
        )}
      </View>
      <View style={s.tabs}>
        {TABS.map(t => (
          <Pressable key={t} onPress={() => setTab(t)} style={s.tab}>
            <Text style={[s.tabText, tab === t && s.tabTextOn]}>
              {t[0].toUpperCase() + t.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base },
  body: { flex: 1 },
  tabs: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: color.line,
    paddingVertical: space.sm,
  },
  tab: { flex: 1, alignItems: 'center', paddingVertical: space.sm },
  tabText: { ...type.label, color: color.textFaint },
  tabTextOn: { color: color.text },
});
