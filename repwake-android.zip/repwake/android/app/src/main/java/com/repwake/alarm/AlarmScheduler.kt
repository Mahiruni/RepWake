package com.repwake.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log

object AlarmScheduler {
    private const val TAG = "RepWake/Scheduler"
    const val EXTRA_ALARM_ID = "alarm_id"
    const val EXTRA_IS_WATCHDOG = "is_watchdog"

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun fireIntent(c: Context, id: String, watchdog: Boolean): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).apply {
            action = "com.repwake.FIRE"
            putExtra(EXTRA_ALARM_ID, id)
            putExtra(EXTRA_IS_WATCHDOG, watchdog)
            // Distinct data keeps the two PendingIntents from colliding.
            data = Uri.parse("repwake://alarm/$id/" + if (watchdog) "wd" else "main")
        }
        return PendingIntent.getBroadcast(
            c, id.hashCode() + if (watchdog) 1 else 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Deep link the system attaches to the lock-screen alarm affordance. */
    private fun showIntent(c: Context, id: String): PendingIntent {
        val i = Intent(c, AlarmActivity::class.java).apply {
            putExtra(EXTRA_ALARM_ID, id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        return PendingIntent.getActivity(
            c, id.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canScheduleExact(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am(c).canScheduleExactAlarms() else true

    /**
     * setAlarmClock() is the only scheduling API fully exempt from Doze and App
     * Standby, and it is the reason this app works at all. It also puts an
     * alarm icon in the status bar, which is a fair trade.
     */
    fun schedule(c: Context, alarm: AlarmDef, at: Long = alarm.nextTrigger()) {
        if (!alarm.enabled) return
        if (!canScheduleExact(c)) {
            Log.w(TAG, "Exact alarms not permitted; ${alarm.id} will not fire on time")
            return
        }
        am(c).setAlarmClock(
            AlarmManager.AlarmClockInfo(at, showIntent(c, alarm.id)),
            fireIntent(c, alarm.id, false)
        )
        Log.i(TAG, "Scheduled ${alarm.id} for $at")
    }

    fun cancel(c: Context, id: String) {
        am(c).cancel(fireIntent(c, id, false))
        cancelWatchdog(c, id)
    }

    fun rescheduleAll(c: Context) {
        AlarmStore.load(c).filter { it.enabled }.forEach { schedule(c, it) }
    }

    /**
     * Re-fires in [delayMs] if the alarm is never dismissed. This covers the
     * service being killed by an aggressive OEM task-killer while ringing.
     *
     * It does NOT survive the user force-stopping the app from Settings.
     * Android puts a force-stopped package into a stopped state and cancels its
     * alarms; nothing we schedule runs until the user opens the app again. No
     * app can work around that, and any that claims to is wrong. Documented in
     * the README rather than papered over.
     */
    fun armWatchdog(c: Context, id: String, delayMs: Long = 60_000) {
        if (!canScheduleExact(c)) return
        val at = System.currentTimeMillis() + delayMs
        am(c).setAlarmClock(
            AlarmManager.AlarmClockInfo(at, showIntent(c, id)),
            fireIntent(c, id, true)
        )
    }

    fun cancelWatchdog(c: Context, id: String) = am(c).cancel(fireIntent(c, id, true))
}
