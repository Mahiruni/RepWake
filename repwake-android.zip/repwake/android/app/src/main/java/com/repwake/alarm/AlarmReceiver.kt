package com.repwake.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_ID) ?: return
        val alarm = AlarmStore.find(context, id) ?: return

        // Start ringing first: we are inside a ~10s broadcast window and the
        // service must reach the foreground well within it.
        val svc = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_START
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, id)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svc)
        } else {
            context.startService(svc)
        }

        // Roll a repeating alarm forward immediately, so a crash between here
        // and dismissal cannot silently drop tomorrow's alarm.
        if (alarm.days.isNotEmpty()) AlarmScheduler.schedule(context, alarm)
    }
}
