package com.repwake.bridge

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import com.facebook.react.bridge.*
import com.repwake.alarm.*
import com.repwake.sensor.SensorBridge

class RepWakeModule(private val ctx: ReactApplicationContext) :
    ReactContextBaseJavaModule(ctx) {

    private val sensors = SensorBridge(ctx)

    override fun getName() = "RepWakeAlarm"

    // --- alarms -------------------------------------------------------------

    /** JS is the source of truth; this mirrors it for BootReceiver. */
    @ReactMethod
    fun syncAlarms(json: String, promise: Promise) {
        AlarmStore.save(ctx, json)
        AlarmScheduler.rescheduleAll(ctx)
        promise.resolve(true)
    }

    @ReactMethod
    fun cancelAlarm(id: String, promise: Promise) {
        AlarmScheduler.cancel(ctx, id)
        promise.resolve(true)
    }

    /** The alarm id that launched the current AlarmActivity, if any. */
    @ReactMethod
    fun getRingingAlarmId(promise: Promise) = promise.resolve(AlarmService.currentAlarmId)

    /**
     * Ends the alarm. [skipped] records that the user took the escape hatch
     * rather than completing the set -- the history log distinguishes the two,
     * and nothing about the app's behaviour punishes a skip.
     */
    @ReactMethod
    fun dismiss(reps: Int, skipped: Boolean, promise: Promise) {
        sensors.stop()
        ctx.startService(Intent(ctx, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        })
        (currentActivity as? AlarmActivity)?.markDismissing()
        promise.resolve(true)
    }

    @ReactMethod
    fun snooze(minutes: Int, promise: Promise) {
        val id = AlarmService.currentAlarmId
        if (id == null) { promise.resolve(false); return }
        val alarm = AlarmStore.find(ctx, id)
        sensors.stop()
        ctx.startService(Intent(ctx, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP
        })
        alarm?.let {
            AlarmScheduler.schedule(ctx, it, System.currentTimeMillis() + minutes * 60_000L)
        }
        (currentActivity as? AlarmActivity)?.markDismissing()
        promise.resolve(true)
    }

    // --- sensors ------------------------------------------------------------

    @ReactMethod
    fun startSensors(mode: String, promise: Promise) {
        sensors.start(useProximity = mode == "proximity")
        promise.resolve(Arguments.createMap().apply {
            putBoolean("hasProximity", sensors.hasProximity())
            putDouble("maxRange", sensors.maxRange.toDouble())
        })
    }

    @ReactMethod fun stopSensors() = sensors.stop()

    // RCTDeviceEventEmitter bookkeeping; required on newer RN to avoid warnings.
    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    // --- permissions & capability -------------------------------------------

    @ReactMethod
    fun getCapabilities(promise: Promise) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        promise.resolve(Arguments.createMap().apply {
            putBoolean("canScheduleExact", AlarmScheduler.canScheduleExact(ctx))
            putBoolean("ignoresBatteryOptimizations", pm.isIgnoringBatteryOptimizations(ctx.packageName))
            putBoolean(
                "canUseFullScreenIntent",
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
                    nm.canUseFullScreenIntent() else true
            )
            putBoolean("hasProximity", sensors.hasProximity())
            putInt("sdkInt", Build.VERSION.SDK_INT)
            putString("manufacturer", Build.MANUFACTURER)
        })
    }

    private fun open(action: String, withPackage: Boolean = true) {
        val i = Intent(action).apply {
            if (withPackage) data = Uri.parse("package:${ctx.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { ctx.startActivity(i) } catch (_: Exception) {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${ctx.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    @ReactMethod
    fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        }
    }

    @ReactMethod
    fun openBatteryOptimizationSettings() =
        open(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)

    @ReactMethod
    fun openFullScreenIntentSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            open(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
        }
    }

    /**
     * Xiaomi, Oppo/Realme, Vivo and Huawei bury an "autostart" toggle that,
     * left off, silently kills scheduled alarms. There is no public API for it,
     * so we open the vendor screen by component name and fall back to app
     * details. See README, "OEM battery killers".
     */
    @ReactMethod
    fun openOemAutostartSettings(promise: Promise) {
        val candidates = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in candidates) {
            try {
                ctx.startActivity(Intent().apply {
                    component = android.content.ComponentName(pkg, cls)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                promise.resolve(true); return
            } catch (_: Exception) { /* try the next one */ }
        }
        open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        promise.resolve(false)
    }
}
