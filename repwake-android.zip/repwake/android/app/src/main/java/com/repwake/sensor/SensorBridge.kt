package com.repwake.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.modules.core.DeviceEventManagerModule

/**
 * Raw sensor plumbing only. Every decision about what counts as a rep lives in
 * TypeScript (src/detection/repMachine.ts) so it can be unit-tested against
 * recorded traces. This class exists to deliver timestamped samples and nothing
 * more.
 *
 * Timestamps come from SensorEvent.timestamp (nanoseconds since boot),
 * converted to ms. Deliberately not Date.now() on the JS side: a stalled JS
 * thread must not be able to fabricate or destroy reps.
 */
class SensorBridge(private val reactContext: ReactApplicationContext) : SensorEventListener {

    private val sm = reactContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val proximity: Sensor? = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    var maxRange: Float = proximity?.maximumRange ?: 5f; private set
    private var running = false

    fun hasProximity() = proximity != null

    fun start(useProximity: Boolean) {
        if (running) return
        running = true
        // ~50Hz. GAME rate rather than FASTEST: enough for a 1-2s movement and
        // markedly cheaper on battery during a long set.
        accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (useProximity) {
            proximity?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
    }

    fun stop() {
        if (!running) return
        running = false
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val t = e.timestamp / 1_000_000.0 // ns -> ms
        val map = Arguments.createMap()
        map.putDouble("t", t)
        when (e.sensor.type) {
            Sensor.TYPE_PROXIMITY -> {
                map.putDouble("raw", e.values[0].toDouble())
                map.putDouble("maxRange", maxRange.toDouble())
                emit("RepWakeProximity", map)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                map.putDouble("x", e.values[0].toDouble())
                map.putDouble("y", e.values[1].toDouble())
                map.putDouble("z", e.values[2].toDouble())
                emit("RepWakeAccel", map)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun emit(name: String, data: com.facebook.react.bridge.WritableMap) {
        if (!reactContext.hasActiveReactInstance()) return
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(name, data)
    }
}
