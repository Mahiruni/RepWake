package com.repwake.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Alarms are owned by the JS layer, but BootReceiver has to reschedule them
 * before React Native has started -- and native code cannot read AsyncStorage
 * or MMKV. So JS mirrors every change here, into SharedPreferences on
 * device-protected storage so it survives direct boot.
 */
data class AlarmDef(
    val id: String,
    val hour: Int,
    val minute: Int,
    /** Calendar.SUNDAY..SATURDAY. Empty = fire once. */
    val days: Set<Int>,
    val label: String,
    val targetReps: Int,
    val mode: String,
    val soundUri: String?,
    val snoozeAllowed: Boolean,
    val enabled: Boolean
) {
    /** Next wall-clock firing time strictly after [from]. */
    fun nextTrigger(from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (days.isEmpty()) {
            if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }
        repeat(8) {
            if (c.timeInMillis > from && days.contains(c.get(Calendar.DAY_OF_WEEK))) {
                return c.timeInMillis
            }
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }
}

object AlarmStore {
    private const val PREFS = "repwake_alarms"
    private const val KEY = "alarms_json"

    /** Device-protected so BootReceiver can read it before first unlock. */
    private fun ctx(context: Context): Context =
        context.createDeviceProtectedStorageContext() ?: context

    fun save(context: Context, json: String) {
        ctx(context).getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, json).apply()
    }

    fun load(context: Context): List<AlarmDef> {
        val raw = ctx(context).getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return try { parse(raw) } catch (e: Exception) { emptyList() }
    }

    fun find(context: Context, id: String): AlarmDef? = load(context).firstOrNull { it.id == id }

    private fun parse(raw: String): List<AlarmDef> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o: JSONObject = arr.getJSONObject(i)
            val d = o.optJSONArray("days")
            AlarmDef(
                id = o.getString("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = (0 until (d?.length() ?: 0)).map { d!!.getInt(it) }.toSet(),
                label = o.optString("label", "Alarm"),
                targetReps = o.optInt("targetReps", 20),
                mode = o.optString("mode", "proximity"),
                soundUri = o.optString("soundUri", "").takeIf { it.isNotBlank() },
                snoozeAllowed = o.optBoolean("snoozeAllowed", false),
                enabled = o.optBoolean("enabled", true)
            )
        }
    }
}
