/**
 * Design tokens.
 *
 * The constraint that drives all of this: the alarm screen is read at 6am, in
 * a dark room, by someone who is not yet awake, holding no opinions about
 * typography. Every choice below is legibility-first.
 *
 * - True black, not a tinted near-black. On the OLED panels most phones ship
 *   with, #000 pixels are literally off: maximum contrast against the counter
 *   and no glow in a dark bedroom.
 * - One accent (amber) means one thing only: "the sensor is reading you". It
 *   never appears decoratively, so a glance at the screen answers the only
 *   question a half-asleep user has.
 * - Green appears for a fraction of a second per counted rep, and nowhere else.
 */

export const color = {
  /** Alarm screen only. */
  void: '#000000',
  /** Everywhere else: config, history, settings. */
  base: '#0E1014',
  surface: '#181B21',
  surfaceRaised: '#22262E',
  line: '#2C313A',

  text: '#F5F7FA',
  textMuted: '#8B939F',
  textFaint: '#5A616B',

  /** "Sensor is live and reading you." Never used as decoration. */
  signal: '#FFC400',
  /** One counted rep. Shown for ~180ms, then gone. */
  confirm: '#35D07F',
  /** The escape hatch, and only the escape hatch. */
  escape: '#FF6B4A',
  danger: '#E5484D',
} as const;

export const space = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 40,
  xxl: 64,
} as const;

export const radius = {
  sm: 8,
  md: 12,
  /** Full-width primary buttons. */
  button: 14,
  pill: 999,
} as const;

export const type = {
  /** The rep count. Sized to be read across a dark room without glasses. */
  counter: {
    fontSize: 172,
    lineHeight: 180,
    fontWeight: '800' as const,
    letterSpacing: -8,
    fontVariant: ['tabular-nums'] as const,
  },
  counterTarget: {
    fontSize: 44,
    fontWeight: '300' as const,
    letterSpacing: -1,
    fontVariant: ['tabular-nums'] as const,
  },
  title: { fontSize: 28, fontWeight: '700' as const, letterSpacing: -0.5 },
  heading: { fontSize: 20, fontWeight: '600' as const },
  body: { fontSize: 16, fontWeight: '400' as const, lineHeight: 24 },
  label: { fontSize: 14, fontWeight: '500' as const },
  small: { fontSize: 13, fontWeight: '400' as const, lineHeight: 19 },
  /** Clock face on the alarm screen. */
  clock: { fontSize: 22, fontWeight: '300' as const, fontVariant: ['tabular-nums'] as const },
} as const;

/** Minimum comfortable touch target, and the height of every primary button. */
export const TOUCH = 56;
