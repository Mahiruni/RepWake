import React from 'react';
import { Pressable, StyleSheet, Switch, Text, View, ViewStyle } from 'react-native';
import { color, radius, space, TOUCH, type } from '../theme';

export const Button = ({
  title,
  onPress,
  variant = 'primary',
  disabled,
}: {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  disabled?: boolean;
}) => (
  <Pressable
    onPress={onPress}
    disabled={disabled}
    accessibilityRole="button"
    style={({ pressed }) => [
      s.btn,
      variant === 'primary' && s.primary,
      variant === 'ghost' && s.ghost,
      variant === 'danger' && s.danger,
      pressed && s.pressed,
      disabled && s.disabled,
    ]}>
    <Text
      style={[
        s.btnText,
        variant === 'ghost' && { color: color.text },
        variant === 'danger' && { color: color.danger },
      ]}>
      {title}
    </Text>
  </Pressable>
);

export const Row = ({
  label,
  hint,
  right,
  onPress,
}: {
  label: string;
  hint?: string;
  right?: React.ReactNode;
  onPress?: () => void;
}) => {
  const Body = (
    <View style={s.row}>
      <View style={s.rowText}>
        <Text style={s.rowLabel}>{label}</Text>
        {hint ? <Text style={s.rowHint}>{hint}</Text> : null}
      </View>
      {right}
    </View>
  );
  return onPress ? (
    <Pressable onPress={onPress} style={({ pressed }) => pressed && { opacity: 0.6 }}>
      {Body}
    </Pressable>
  ) : (
    Body
  );
};

export const Toggle = ({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) => (
  <Switch
    value={value}
    onValueChange={onChange}
    trackColor={{ false: color.line, true: color.confirm }}
    thumbColor={color.text}
  />
);

export const Card = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => (
  <View style={[s.card, style]}>{children}</View>
);

export const Screen = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <View style={s.screen}>
    <Text style={s.title}>{title}</Text>
    {children}
  </View>
);

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: color.base, padding: space.md, gap: space.md },
  title: { ...type.title, color: color.text, marginTop: space.lg, marginBottom: space.sm },
  btn: {
    height: TOUCH,
    width: '100%',
    borderRadius: radius.button,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: { backgroundColor: color.confirm },
  ghost: { borderWidth: 1, borderColor: color.line },
  danger: { borderWidth: 1, borderColor: color.danger },
  pressed: { opacity: 0.75 },
  disabled: { opacity: 0.4 },
  btnText: { ...type.heading, color: color.void },
  row: {
    minHeight: TOUCH,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: space.md,
    paddingVertical: space.sm,
  },
  rowText: { flex: 1, gap: 2 },
  rowLabel: { ...type.body, color: color.text },
  rowHint: { ...type.small, color: color.textMuted },
  card: {
    backgroundColor: color.surface,
    borderRadius: radius.md,
    padding: space.md,
    gap: space.xs,
  },
});
