import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { MMKV } from 'react-native-mmkv';
import { Native } from '../native/RepWakeAlarm';
import { DetectionMode } from '../detection/types';

const mmkv = new MMKV({ id: 'repwake' });

const storage = createJSONStorage(() => ({
  getItem: (k: string) => mmkv.getString(k) ?? null,
  setItem: (k: string, v: string) => mmkv.set(k, v),
  removeItem: (k: string) => mmkv.delete(k),
}));

export interface Alarm {
  id: string;
  hour: number;
  minute: number;
  /** 1 = Sunday .. 7 = Saturday, matching java.util.Calendar. */
  days: number[];
  label: string;
  targetReps: number;
  mode: DetectionMode;
  soundUri?: string;
  snoozeAllowed: boolean;
  enabled: boolean;
}

export interface HistoryEntry {
  alarmId: string;
  date: string;
  wakeTime: string;
  repsCompleted: number;
  targetReps: number;
  durationMs: number;
  skipped: boolean;
}

export interface Settings {
  volumeRampMs: number;
  vibrate: boolean;
  /** Clamped again in EscapeHatch; never trust this value alone. */
  escapeHatchDelayMs: number;
  /** Proximity threshold from the calibration step, per device. */
  nearThreshold: number;
  calibrated: boolean;
}

interface AlarmStore {
  alarms: Alarm[];
  upsert: (a: Alarm) => void;
  remove: (id: string) => void;
  toggle: (id: string, enabled: boolean) => void;
}

/** Native owns rescheduling and boot recovery, so every write mirrors across. */
const sync = (alarms: Alarm[]) => {
  Native.syncAlarms(JSON.stringify(alarms)).catch(() => {});
};

export const useAlarms = create<AlarmStore>()(
  persist(
    (set, get) => ({
      alarms: [],
      upsert: a => {
        const next = get().alarms.some(x => x.id === a.id)
          ? get().alarms.map(x => (x.id === a.id ? a : x))
          : [...get().alarms, a];
        set({ alarms: next });
        sync(next);
      },
      remove: id => {
        const next = get().alarms.filter(x => x.id !== id);
        set({ alarms: next });
        Native.cancelAlarm(id).catch(() => {});
        sync(next);
      },
      toggle: (id, enabled) => {
        const next = get().alarms.map(x => (x.id === id ? { ...x, enabled } : x));
        set({ alarms: next });
        if (!enabled) Native.cancelAlarm(id).catch(() => {});
        sync(next);
      },
    }),
    { name: 'alarms', storage, onRehydrateStorage: () => s => s && sync(s.alarms) },
  ),
);

export const useSettings = create<Settings & { patch: (p: Partial<Settings>) => void }>()(
  persist(
    set => ({
      volumeRampMs: 30_000,
      vibrate: true,
      escapeHatchDelayMs: 3 * 60 * 1000,
      nearThreshold: 3,
      calibrated: false,
      patch: p => set(p),
    }),
    { name: 'settings', storage },
  ),
);

export const useHistory = create<{
  entries: HistoryEntry[];
  add: (e: HistoryEntry) => void;
  clear: () => void;
}>()(
  persist(
    (set, get) => ({
      entries: [],
      add: e => set({ entries: [e, ...get().entries].slice(0, 365) }),
      clear: () => set({ entries: [] }),
    }),
    { name: 'history', storage },
  ),
);
