import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, View, Pressable } from 'react-native';
import { Button, Card, Row, Toggle } from '../components/Primitives';
import { useSettings } from '../state/store';
import { getGates, Gate } from '../permissions';
import { color, radius, space, type } from '../theme';

const ESCAPE_OPTIONS = [1, 3, 5, 10]; // minutes; 10 is the hard ceiling

export default function SettingsScreen({ onCalibrate }: { onCalibrate: () => void }) {
  const settings = useSettings();
  const [gates, setGates] = useState<Gate[]>([]);

  useEffect(() => {
    getGates().then(setGates);
  }, []);

  return (
    <ScrollView style={s.root} contentContainerStyle={s.content}>
      <Text style={s.title}>Settings</Text>

      {gates.some(g => !g.satisfied) ? (
        <Card>
          <Text style={s.section}>Needs your permission</Text>
          {gates
            .filter(g => !g.satisfied)
            .map(g => (
              <Row
                key={g.key}
                label={g.title}
                hint={g.why}
                onPress={g.open}
                right={<Text style={s.fix}>Fix</Text>}
              />
            ))}
        </Card>
      ) : null}

      <Card>
        <Text style={s.section}>Alarm</Text>
        <Row
          label="Vibrate"
          right={<Toggle value={settings.vibrate} onChange={v => settings.patch({ vibrate: v })} />}
        />
        <Row
          label="Volume ramp"
          hint="How long the alarm takes to reach full volume"
          right={
            <View style={s.chips}>
              {[10, 30, 60].map(sec => (
                <Pressable
                  key={sec}
                  onPress={() => settings.patch({ volumeRampMs: sec * 1000 })}
                  style={[s.chip, settings.volumeRampMs === sec * 1000 && s.chipOn]}>
                  <Text style={s.chipText}>{sec}s</Text>
                </Pressable>
              ))}
            </View>
          }
        />
      </Card>

      <Card>
        <Text style={s.section}>Getting out</Text>
        <Text style={s.body}>
          If you're hurt, ill, or something's wrong, you can stop the alarm
          without finishing. The button appears after the delay below, then
          holds for 60 seconds. It can't be turned off, and a skip isn't held
          against you.
        </Text>
        <View style={s.chips}>
          {ESCAPE_OPTIONS.map(m => (
            <Pressable
              key={m}
              onPress={() => settings.patch({ escapeHatchDelayMs: m * 60_000 })}
              style={[s.chip, settings.escapeHatchDelayMs === m * 60_000 && s.chipOn]}>
              <Text style={s.chipText}>{m} min</Text>
            </Pressable>
          ))}
        </View>
      </Card>

      <Card>
        <Text style={s.section}>Detection</Text>
        <Row
          label="Calibrate the proximity sensor"
          hint={
            settings.calibrated
              ? 'Redo this if you change phone case.'
              : 'Not calibrated yet. Do this before your first alarm.'
          }
          onPress={onCalibrate}
          right={<Text style={s.fix}>{settings.calibrated ? 'Redo' : 'Start'}</Text>}
        />
      </Card>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base },
  content: { padding: space.md, gap: space.md, paddingBottom: space.xxl },
  title: { ...type.title, color: color.text, marginTop: space.lg },
  section: { ...type.heading, color: color.text, marginBottom: space.xs },
  body: { ...type.small, color: color.textMuted },
  fix: { ...type.label, color: color.signal },
  chips: { flexDirection: 'row', gap: space.sm, flexWrap: 'wrap' },
  chip: {
    paddingHorizontal: space.md,
    paddingVertical: space.sm,
    borderRadius: radius.pill,
    backgroundColor: color.surfaceRaised,
  },
  chipOn: { backgroundColor: color.confirm },
  chipText: { ...type.label, color: color.text },
});
