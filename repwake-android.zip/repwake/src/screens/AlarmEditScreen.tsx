import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, View, Pressable } from 'react-native';
import { Button, Card, Row, Toggle } from '../components/Primitives';
import { useAlarms, Alarm } from '../state/store';
import { color, radius, space, TOUCH, type } from '../theme';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const blank = (): Alarm => ({
  id: String(Date.now()),
  hour: 6,
  minute: 30,
  days: [2, 3, 4, 5, 6],
  label: '',
  targetReps: 20,
  mode: 'proximity',
  snoozeAllowed: false,
  enabled: true,
});

export default function AlarmEditScreen({
  id,
  onDone,
}: {
  id?: string;
  onDone: () => void;
}) {
  const { alarms, upsert, remove } = useAlarms();
  const [a, setA] = useState<Alarm>(alarms.find(x => x.id === id) ?? blank());
  const set = (p: Partial<Alarm>) => setA({ ...a, ...p });

  const num = (v: string, max: number) =>
    Math.max(0, Math.min(max, parseInt(v.replace(/\D/g, ''), 10) || 0));

  return (
    <ScrollView style={s.root} contentContainerStyle={s.content}>
      <Text style={s.title}>{id ? 'Edit alarm' : 'New alarm'}</Text>

      <Card>
        <View style={s.timeRow}>
          <TextInput
            style={s.timeInput}
            keyboardType="number-pad"
            maxLength={2}
            value={String(a.hour).padStart(2, '0')}
            onChangeText={v => set({ hour: num(v, 23) })}
          />
          <Text style={s.colon}>:</Text>
          <TextInput
            style={s.timeInput}
            keyboardType="number-pad"
            maxLength={2}
            value={String(a.minute).padStart(2, '0')}
            onChangeText={v => set({ minute: num(v, 59) })}
          />
        </View>
        <View style={s.days}>
          {DAYS.map((d, i) => {
            const day = i + 1;
            const on = a.days.includes(day);
            return (
              <Pressable
                key={d}
                onPress={() =>
                  set({
                    days: on ? a.days.filter(x => x !== day) : [...a.days, day].sort(),
                  })
                }
                style={[s.day, on && s.dayOn]}>
                <Text style={[s.dayText, on && s.dayTextOn]}>{d[0]}</Text>
              </Pressable>
            );
          })}
        </View>
      </Card>

      <Card>
        <Row
          label="Label"
          right={
            <TextInput
              style={s.text}
              placeholder="Morning"
              placeholderTextColor={color.textFaint}
              value={a.label}
              onChangeText={v => set({ label: v })}
            />
          }
        />
        <Row
          label="Reps to dismiss"
          hint="5 to 50"
          right={
            <View style={s.stepper}>
              <Pressable
                onPress={() => set({ targetReps: Math.max(5, a.targetReps - 1) })}
                style={s.step}>
                <Text style={s.stepText}>−</Text>
              </Pressable>
              <Text style={s.stepValue}>{a.targetReps}</Text>
              <Pressable
                onPress={() => set({ targetReps: Math.min(50, a.targetReps + 1) })}
                style={s.step}>
                <Text style={s.stepText}>+</Text>
              </Pressable>
            </View>
          }
        />
        <Row
          label="Detection"
          hint={
            a.mode === 'proximity'
              ? 'Phone on the floor under your chest'
              : 'Phone strapped to your arm. Less accurate.'
          }
          right={
            <Pressable
              onPress={() => set({ mode: a.mode === 'proximity' ? 'accel' : 'proximity' })}
              style={s.chip}>
              <Text style={s.chipText}>{a.mode === 'proximity' ? 'Floor' : 'Armband'}</Text>
            </Pressable>
          }
        />
        <Row
          label="Allow snooze"
          hint="Snoozing still requires the reps when it fires again"
          right={
            <Toggle value={a.snoozeAllowed} onChange={v => set({ snoozeAllowed: v })} />
          }
        />
      </Card>

      <Button
        title="Save alarm"
        onPress={() => {
          upsert(a);
          onDone();
        }}
      />
      {id ? (
        <Button
          title="Delete alarm"
          variant="danger"
          onPress={() => {
            remove(a.id);
            onDone();
          }}
        />
      ) : null}
      <Button title="Cancel" variant="ghost" onPress={onDone} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base },
  content: { padding: space.md, gap: space.md, paddingBottom: space.xxl },
  title: { ...type.title, color: color.text, marginTop: space.lg },
  timeRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  timeInput: {
    fontSize: 64,
    fontWeight: '700',
    color: color.text,
    fontVariant: ['tabular-nums'],
    textAlign: 'center',
    minWidth: 100,
  },
  colon: { fontSize: 56, color: color.textFaint, marginHorizontal: space.xs },
  days: { flexDirection: 'row', justifyContent: 'space-between', marginTop: space.md },
  day: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: color.line,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayOn: { backgroundColor: color.confirm, borderColor: color.confirm },
  dayText: { ...type.label, color: color.textMuted },
  dayTextOn: { color: color.void, fontWeight: '700' },
  text: { ...type.body, color: color.text, minWidth: 140, textAlign: 'right' },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: space.sm },
  step: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    backgroundColor: color.surfaceRaised,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepText: { fontSize: 22, color: color.text },
  stepValue: {
    ...type.heading,
    color: color.text,
    minWidth: 32,
    textAlign: 'center',
    fontVariant: ['tabular-nums'],
  },
  chip: {
    paddingHorizontal: space.md,
    height: 40,
    justifyContent: 'center',
    borderRadius: radius.pill,
    backgroundColor: color.surfaceRaised,
  },
  chipText: { ...type.label, color: color.text },
});
