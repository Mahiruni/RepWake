import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button, Card } from '../components/Primitives';
import { Native, onProximity } from '../native/RepWakeAlarm';
import { calibrate, CalibrationSample } from '../detection/calibration';
import { useSettings } from '../state/store';
import { color, space, type } from '../theme';

type Step = 'intro' | 'uncovered' | 'covered' | 'result';

/**
 * First-run calibration. Proximity sensors vary enormously between phones, and
 * a case can shift or flatten the range entirely, so the threshold is measured
 * per device rather than assumed.
 */
export default function CalibrationScreen({ onDone }: { onDone: () => void }) {
  const settings = useSettings();
  const [step, setStep] = useState<Step>('intro');
  const [result, setResult] = useState<ReturnType<typeof calibrate> | null>(null);
  const [live, setLive] = useState(0);
  const buf = useRef<CalibrationSample[]>([]);
  const uncovered = useRef<CalibrationSample[]>([]);

  useEffect(() => {
    if (step === 'intro' || step === 'result') return;
    Native.startSensors('proximity');
    buf.current = [];
    const sub = onProximity(s => {
      setLive(s.raw);
      buf.current.push({ raw: s.raw, t: s.t });
    });
    const t = setTimeout(() => {
      if (step === 'uncovered') {
        uncovered.current = buf.current;
        setStep('covered');
      } else {
        setResult(calibrate(uncovered.current, buf.current));
        setStep('result');
      }
    }, 2500);
    return () => {
      sub.remove();
      clearTimeout(t);
      Native.stopSensors();
    };
  }, [step]);

  return (
    <View style={s.root}>
      <Text style={s.title}>Calibrate</Text>

      {step === 'intro' && (
        <>
          <Card>
            <Text style={s.body}>
              RepWake counts reps with the small sensor near your earpiece.
              Every phone reads it differently, and a case changes it again, so
              it needs two quick readings.
            </Text>
          </Card>
          <Button title="Start" onPress={() => setStep('uncovered')} />
        </>
      )}

      {step === 'uncovered' && (
        <Card>
          <Text style={s.instruction}>Leave the top of the phone clear</Text>
          <Text style={s.body}>Hold still for a couple of seconds.</Text>
          <Text style={s.reading}>{live.toFixed(1)}</Text>
        </Card>
      )}

      {step === 'covered' && (
        <Card>
          <Text style={s.instruction}>Now cover the top with your palm</Text>
          <Text style={s.body}>Flat against the glass, near the earpiece.</Text>
          <Text style={s.reading}>{live.toFixed(1)}</Text>
        </Card>
      )}

      {step === 'result' && result && (
        <>
          <Card>
            <Text style={s.instruction}>
              {result.usable ? 'Sensor looks good' : 'This sensor will struggle'}
            </Text>
            <Text style={s.body}>
              {result.problem ??
                `Clear reading of ${result.farBaseline.toFixed(1)} uncovered and ` +
                  `${result.nearBaseline.toFixed(1)} covered. That's plenty to count reps.`}
            </Text>
          </Card>
          <Button
            title={result.usable ? 'Save' : 'Save anyway'}
            onPress={() => {
              settings.patch({ nearThreshold: result.nearThreshold, calibrated: true });
              onDone();
            }}
          />
          <Button title="Try again" variant="ghost" onPress={() => setStep('uncovered')} />
        </>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base, padding: space.md, gap: space.md },
  title: { ...type.title, color: color.text, marginTop: space.lg },
  instruction: { ...type.heading, color: color.text },
  body: { ...type.body, color: color.textMuted },
  reading: {
    fontSize: 56,
    fontWeight: '300',
    color: color.signal,
    fontVariant: ['tabular-nums'],
    textAlign: 'center',
    marginTop: space.md,
  },
});
