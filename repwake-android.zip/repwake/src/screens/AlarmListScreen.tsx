import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Button, Card, Toggle } from '../components/Primitives';
import { useAlarms, Alarm } from '../state/store';
import { color, space, type } from '../theme';

const DAY = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

const describe = (a: Alarm) => {
  if (!a.days.length) return 'Once';
  if (a.days.length === 7) return 'Every day';
  return a.days.map(d => DAY[d - 1]).join(' ');
};

export default function AlarmListScreen({ onEdit }: { onEdit: (id?: string) => void }) {
  const { alarms, toggle } = useAlarms();

  return (
    <View style={s.root}>
      <Text style={s.title}>Alarms</Text>
      <FlatList
        data={alarms}
        keyExtractor={a => a.id}
        contentContainerStyle={{ gap: space.sm, paddingBottom: space.xl }}
        ListEmptyComponent={
          <Card>
            <Text style={s.emptyTitle}>No alarms yet</Text>
            <Text style={s.emptyBody}>
              Add one, then put your phone on the floor tonight. It won't turn
              off until you've done your reps.
            </Text>
          </Card>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => onEdit(item.id)}>
            <Card>
              <View style={s.head}>
                <Text style={[s.time, !item.enabled && s.off]}>
                  {String(item.hour).padStart(2, '0')}:
                  {String(item.minute).padStart(2, '0')}
                </Text>
                <Toggle value={item.enabled} onChange={v => toggle(item.id, v)} />
              </View>
              <Text style={s.meta}>
                {describe(item)} · {item.targetReps} reps ·{' '}
                {item.mode === 'accel' ? 'armband' : 'floor'}
              </Text>
              {item.label ? <Text style={s.label}>{item.label}</Text> : null}
            </Card>
          </Pressable>
        )}
      />
      <Button title="Add alarm" onPress={() => onEdit()} />
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base, padding: space.md, gap: space.md },
  title: { ...type.title, color: color.text, marginTop: space.lg },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  time: { fontSize: 44, fontWeight: '700', color: color.text, fontVariant: ['tabular-nums'] },
  off: { color: color.textFaint },
  meta: { ...type.small, color: color.textMuted },
  label: { ...type.label, color: color.textMuted },
  emptyTitle: { ...type.heading, color: color.text },
  emptyBody: { ...type.small, color: color.textMuted },
});
