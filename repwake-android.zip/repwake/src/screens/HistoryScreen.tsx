import React from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { Card } from '../components/Primitives';
import { useHistory } from '../state/store';
import { color, space, type } from '../theme';

const mmss = (ms: number) => {
  const s = Math.round(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

export default function HistoryScreen() {
  const entries = useHistory(s => s.entries);

  return (
    <View style={s.root}>
      <Text style={s.title}>History</Text>
      <FlatList
        data={entries}
        keyExtractor={(e, i) => e.date + i}
        contentContainerStyle={{ gap: space.sm, paddingBottom: space.xl }}
        ListEmptyComponent={
          <Card>
            <Text style={s.empty}>Nothing yet. Your first morning will show up here.</Text>
          </Card>
        }
        renderItem={({ item }) => (
          <Card>
            <View style={s.head}>
              <Text style={s.date}>
                {new Date(item.date).toLocaleDateString(undefined, {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short',
                })}
              </Text>
              <Text style={s.time}>
                {new Date(item.wakeTime).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </Text>
            </View>
            <Text style={[s.result, item.skipped && s.skipped]}>
              {item.skipped
                ? `Stopped early at ${item.repsCompleted} of ${item.targetReps}`
                : `${item.repsCompleted} reps in ${mmss(item.durationMs)}`}
            </Text>
          </Card>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: color.base, padding: space.md, gap: space.md },
  title: { ...type.title, color: color.text, marginTop: space.lg },
  head: { flexDirection: 'row', justifyContent: 'space-between' },
  date: { ...type.body, color: color.text },
  time: { ...type.body, color: color.textMuted, fontVariant: ['tabular-nums'] },
  result: { ...type.small, color: color.confirm },
  // A skip is recorded neutrally. No red, no penalty, no broken streak.
  skipped: { color: color.textMuted },
  empty: { ...type.small, color: color.textMuted },
});
