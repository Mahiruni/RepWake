import { PermissionsAndroid, Platform } from 'react-native';
import { Capabilities, Native } from './native/RepWakeAlarm';

export interface Gate {
  key: 'notifications' | 'exactAlarm' | 'fullScreenIntent' | 'battery' | 'oemAutostart';
  title: string;
  /** Written to explain the consequence, not to sell the permission. */
  why: string;
  satisfied: boolean;
  required: boolean;
  open: () => void;
}

/**
 * The prompts are ordered by how badly the alarm breaks without them, and each
 * one says what actually goes wrong. A user who declines should understand
 * exactly which failure they have chosen.
 */
export async function getGates(): Promise<Gate[]> {
  if (Platform.OS !== 'android') return [];
  const caps: Capabilities = await Native.getCapabilities();

  const notifGranted =
    Platform.Version < 33 ||
    (await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
    ));

  const oem = /xiaomi|redmi|poco|oppo|realme|vivo|huawei|honor/i.test(caps.manufacturer);

  return [
    {
      key: 'notifications',
      title: 'Allow notifications',
      why: 'The alarm runs as a notification. Without this it cannot start at all.',
      satisfied: notifGranted,
      required: true,
      open: () =>
        PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS),
    },
    {
      key: 'exactAlarm',
      title: 'Allow exact alarms',
      why: 'Without it, Android may hold the alarm back by up to an hour while the phone is idle.',
      satisfied: caps.canScheduleExact,
      required: true,
      open: () => Native.openExactAlarmSettings(),
    },
    {
      key: 'fullScreenIntent',
      title: 'Allow full-screen alarms',
      why: 'Lets the rep counter open over the lock screen. Without it you get a notification you can swipe away.',
      satisfied: caps.canUseFullScreenIntent,
      required: true,
      open: () => Native.openFullScreenIntentSettings(),
    },
    {
      key: 'battery',
      title: 'Turn off battery optimisation',
      why: 'Battery optimisation can kill the alarm while it is ringing.',
      satisfied: caps.ignoresBatteryOptimizations,
      required: false,
      open: () => Native.openBatteryOptimizationSettings(),
    },
    ...(oem
      ? [
          {
            key: 'oemAutostart' as const,
            title: `Allow autostart on ${caps.manufacturer}`,
            why: 'This phone kills background alarms unless autostart is enabled. We cannot check whether you did it — please confirm the toggle is on.',
            satisfied: false,
            required: false,
            open: () => { Native.openOemAutostartSettings(); },
          },
        ]
      : []),
  ];
}
