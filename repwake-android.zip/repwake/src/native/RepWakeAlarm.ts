import { NativeEventEmitter, NativeModules } from 'react-native';

const { RepWakeAlarm } = NativeModules;

export interface Capabilities {
  canScheduleExact: boolean;
  ignoresBatteryOptimizations: boolean;
  canUseFullScreenIntent: boolean;
  hasProximity: boolean;
  sdkInt: number;
  manufacturer: string;
}

export interface ProximitySample { raw: number; maxRange: number; t: number }
export interface AccelSample { x: number; y: number; z: number; t: number }

interface RepWakeNative {
  syncAlarms(json: string): Promise<boolean>;
  cancelAlarm(id: string): Promise<boolean>;
  getRingingAlarmId(): Promise<string | null>;
  dismiss(reps: number, skipped: boolean): Promise<boolean>;
  snooze(minutes: number): Promise<boolean>;
  startSensors(mode: 'proximity' | 'accel'): Promise<{ hasProximity: boolean; maxRange: number }>;
  stopSensors(): void;
  getCapabilities(): Promise<Capabilities>;
  openExactAlarmSettings(): void;
  openBatteryOptimizationSettings(): void;
  openFullScreenIntentSettings(): void;
  openOemAutostartSettings(): Promise<boolean>;
}

export const Native = RepWakeAlarm as RepWakeNative;
export const NativeEvents = new NativeEventEmitter(RepWakeAlarm);

export const onProximity = (cb: (s: ProximitySample) => void) =>
  NativeEvents.addListener('RepWakeProximity', cb);

export const onAccel = (cb: (s: AccelSample) => void) =>
  NativeEvents.addListener('RepWakeAccel', cb);
