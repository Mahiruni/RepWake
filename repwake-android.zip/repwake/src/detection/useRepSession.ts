import { useCallback, useEffect, useRef, useState } from 'react';
import { Native, onAccel, onProximity } from '../native/RepWakeAlarm';
import { initialState, reduce } from './repMachine';
import { isNear } from './calibration';
import { Effect, RepConfig, RepState } from './types';

/**
 * Wires native sensor events into the pure state machine.
 *
 * Everything stateful is in refs and the machine is driven synchronously on
 * each sample; React only sees the rendered snapshot. At ~50Hz across two
 * sensors, a setState per sample would drop reps on slower devices.
 */
export function useRepSession(cfg: RepConfig, onEffect: (e: Effect) => void) {
  const machine = useRef<RepState>(initialState(0));
  const near = useRef(false);
  const [snapshot, setSnapshot] = useState<RepState>(machine.current);
  const [proximityLive, setProximityLive] = useState(false);

  const push = useCallback(
    (event: Parameters<typeof reduce>[1]) => {
      const { state, effects } = reduce(machine.current, event, cfg);
      machine.current = state;
      effects.forEach(onEffect);
      if (effects.length) setSnapshot(state);
    },
    [cfg, onEffect],
  );

  useEffect(() => {
    let alive = true;
    Native.startSensors(cfg.mode);

    const subProx = onProximity(s => {
      if (!alive) return;
      const n = isNear(s.raw, cfg.nearThreshold);
      setProximityLive(n);
      if (n === near.current) return;
      near.current = n;
      push({ type: 'PROXIMITY', near: n, raw: s.raw, t: s.t });
    });

    const subAccel = onAccel(s => {
      if (!alive) return;
      push({ type: 'ACCEL', v: { x: s.x, y: s.y, z: s.z }, t: s.t });
    });

    // Drives the stall timeout when the user is holding perfectly still and no
    // sensor is reporting a change.
    const tick = setInterval(() => {
      if (alive) push({ type: 'TICK', t: Date.now() });
    }, 250);

    // Keeps the counter visibly alive even during a long quiet stretch.
    const repaint = setInterval(() => {
      if (alive) setSnapshot({ ...machine.current });
    }, 400);

    return () => {
      alive = false;
      subProx.remove();
      subAccel.remove();
      clearInterval(tick);
      clearInterval(repaint);
      Native.stopSensors();
    };
  }, [cfg, push]);

  const setTouching = useCallback(
    (down: boolean) => push({ type: 'TOUCH', down, t: Date.now() }),
    [push],
  );

  return { state: snapshot, proximityLive, setTouching };
}
