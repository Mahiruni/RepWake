export type DetectionMode = 'proximity' | 'accel';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

/**
 * All events carry `t` — a monotonic timestamp in milliseconds sourced from
 * the *sensor event itself* (SensorEvent.timestamp, converted), never from
 * Date.now() on the JS thread. A stalled JS thread must not be able to
 * fabricate or destroy reps.
 */
export type RepEvent =
  | { type: 'PROXIMITY'; near: boolean; raw: number; t: number }
  | { type: 'ACCEL'; v: Vec3; t: number }
  | { type: 'TOUCH'; down: boolean; t: number }
  | { type: 'TICK'; t: number };

export type RejectReason =
  | 'flick'           // NEAR released before the hold threshold
  | 'too_fast'        // under minRepGapMs since the last counted rep
  | 'stalled'         // over maxRepMs in the down position
  | 'device_moved'    // accelerometer says the phone was picked up / waved
  | 'touching';       // screen under a finger while the rep completed

export type Phase =
  | 'WAITING_DOWN'    // proximity: expecting a NEAR. accel: expecting a dip.
  | 'CONFIRMING_NEAR' // NEAR seen, waiting out minNearHoldMs
  | 'HELD_NEAR'       // hold satisfied; a FAR now completes the rep
  | 'DIPPED'          // accel mode: below the low threshold
  | 'DONE';

export interface RepConfig {
  mode: DetectionMode;
  targetReps: number;

  /** Rejects hand-waving spam. */
  minRepGapMs: number;
  /** Auto-reset if a rep stalls at the bottom. */
  maxRepMs: number;
  /** Rejects flicks past the sensor. */
  minNearHoldMs: number;

  /**
   * Max gravity-vector drift (degrees) inside one rep window. Primary
   * anti-cheat signal: a phone lying on the floor cannot rotate, however hard
   * you land next to it.
   */
  maxTiltDeg: number;
  /**
   * Max "rest floor" (m/s^2): the quietest 100ms of the rep window. A phone on
   * the floor goes genuinely still between reps; a hand always trembles. This
   * catches the level-translation cheat that tilt alone would miss.
   */
  maxRestJerk: number;
  /** Samples in the rest-floor moving average (100ms at 50Hz). */
  restWindowSamples: number;
  /**
   * After this many consecutive device_moved rejections we assume WE are
   * wrong, not the user. See Effect.SUSPECT_MISCALIBRATION.
   */
  miscalibrationAfter: number;

  /** Proximity: raw reading below this counts as NEAR. Set by calibration. */
  nearThreshold: number;

  /** Accel-only mode: Schmitt trigger bands, m/s^2 of linear vertical accel. */
  accelLowThreshold: number;
  accelHighThreshold: number;
  /** EMA smoothing for the vertical signal (0..1, lower = smoother). */
  lowPassAlpha: number;
  /** EMA smoothing for the gravity estimate. */
  gravityAlpha: number;
}

export const DEFAULT_CONFIG: RepConfig = {
  mode: 'proximity',
  targetReps: 20,
  minRepGapMs: 900,
  maxRepMs: 8000,
  minNearHoldMs: 250,
  maxTiltDeg: 25,
  maxRestJerk: 0.06,
  restWindowSamples: 5,
  miscalibrationAfter: 4,
  nearThreshold: 3.0,
  accelLowThreshold: -1.5,
  accelHighThreshold: 1.5,
  lowPassAlpha: 0.2,
  gravityAlpha: 0.05,
};

export interface RepState {
  phase: Phase;
  reps: number;
  startedAt: number;
  lastRepAt: number;

  /** Start of the current rep attempt. */
  windowStart: number;
  nearSince: number;
  near: boolean;
  touching: boolean;

  // Accelerometer cross-validation, reset at each window start.
  ref: Vec3 | null;
  lastAccel: Vec3 | null;
  maxTilt: number;
  /** Recent per-sample jerk magnitudes, for the rest-floor test. */
  jerkBuf: number[];
  minRestJerk: number;
  consecutiveMoveRejects: number;

  // Accel-only detection.
  gravity: Vec3 | null;
  vertical: number;

  lastReject: RejectReason | null;
  rejectCount: number;
}

export type Effect =
  | { type: 'REP'; index: number; durationMs: number }
  | { type: 'REJECT'; reason: RejectReason }
  | { type: 'RESET' }
  | { type: 'COMPLETE'; totalMs: number }
  /**
   * Repeated device_moved rejections on a user who is probably doing real
   * push-ups. The UI must respond by offering recalibration and bringing the
   * escape hatch forward — never by silently continuing to refuse reps.
   */
  | { type: 'SUSPECT_MISCALIBRATION'; consecutive: number };
