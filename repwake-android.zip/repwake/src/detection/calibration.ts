/**
 * Proximity calibration.
 *
 * Android proximity sensors are wildly inconsistent. Most report a binary
 * 0 / maxRange. Some report centimetres. A thick case, a screen protector, or
 * a lens ring can shift the far baseline, compress the usable range, or pin
 * the sensor permanently NEAR. So we never hardcode a threshold — we measure
 * one on first run and re-offer calibration if detection starts failing.
 */

export interface CalibrationSample {
  raw: number;
  t: number;
}

export interface CalibrationResult {
  farBaseline: number;
  nearBaseline: number;
  nearThreshold: number;
  /** Binary sensors report exactly two values; useful to know for the UI. */
  isBinary: boolean;
  usable: boolean;
  /** Shown to the user verbatim when usable is false. */
  problem?: string;
}

const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
};

/**
 * @param uncovered readings taken with nothing over the sensor
 * @param covered   readings taken with a hand flat over the sensor
 */
export function calibrate(
  uncovered: CalibrationSample[],
  covered: CalibrationSample[],
): CalibrationResult {
  const far = median(uncovered.map(s => s.raw));
  const near = median(covered.map(s => s.raw));

  const distinct = new Set([...uncovered, ...covered].map(s => s.raw));
  const isBinary = distinct.size <= 2;

  const spread = far - near;

  if (spread <= 0) {
    return {
      farBaseline: far,
      nearBaseline: near,
      nearThreshold: near,
      isBinary,
      usable: false,
      problem:
        'The sensor reads the same covered and uncovered. A thick case is usually the cause. Take the case off, or switch this alarm to armband mode.',
    };
  }

  if (!isBinary && spread < 1.0) {
    return {
      farBaseline: far,
      nearBaseline: near,
      nearThreshold: near + spread / 2,
      isBinary,
      usable: false,
      problem:
        'The sensor can barely tell covered from uncovered, so reps would be missed. Take the case off, or switch this alarm to armband mode.',
    };
  }

  // Bias the threshold toward the near end: a false FAR ends a rep early,
  // which is far more annoying than a slightly late NEAR.
  return {
    farBaseline: far,
    nearBaseline: near,
    nearThreshold: near + spread * 0.4,
    isBinary,
    usable: true,
  };
}

export const isNear = (raw: number, threshold: number) => raw < threshold;
