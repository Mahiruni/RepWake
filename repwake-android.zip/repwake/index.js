import { AppRegistry } from 'react-native';
import React from 'react';
import App from './App';
import AlarmRingingScreen from './src/screens/AlarmRingingScreen';
import { useAlarms, useSettings } from './src/state/store';
import { DEFAULT_CONFIG } from './src/detection/types';
import { name as appName } from './app.json';

/**
 * Two roots. AlarmActivity mounts "RepWakeAlarm" directly, so the ringing
 * screen never sits behind navigation state that could fail to load at 6am.
 */
function AlarmRoot(props) {
  const alarmId = props?.alarm_id ?? '';
  const alarm = useAlarms.getState().alarms.find(a => a.id === alarmId);
  const settings = useSettings.getState();

  return (
    <AlarmRingingScreen
      alarmId={alarmId}
      label={alarm?.label || 'Alarm'}
      config={{
        ...DEFAULT_CONFIG,
        mode: alarm?.mode ?? 'proximity',
        targetReps: alarm?.targetReps ?? 20,
        nearThreshold: settings.nearThreshold,
      }}
    />
  );
}

AppRegistry.registerComponent(appName, () => App);
AppRegistry.registerComponent('RepWakeAlarm', () => AlarmRoot);
